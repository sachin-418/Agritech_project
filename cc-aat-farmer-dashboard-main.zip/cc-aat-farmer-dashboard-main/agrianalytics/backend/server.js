import "dotenv/config";
import express from "express";
import cors from "cors";
import mongoose from "mongoose";

import climateRoutes from "./routes/climate.js";
import cropRoutes from "./routes/crops.js";
import monthlyClimateRoutes from "./routes/monthlyClimate.js";
import alertRoutes from "./routes/alerts.js";
import insightRoutes from "./routes/insights.js";
import heatmapRoutes from "./routes/heatmap.js";
import analyticsRoutes from "./routes/analytics.js";
import settingsRoutes from "./routes/settings.js";
import weatherRoutes from "./routes/weather.js";
import fieldReportRoutes from "./routes/fieldReports.js";
import authRoutes from "./routes/auth.js";

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({ origin: ["http://localhost:8080", "http://localhost:5173"] }));
app.use(express.json());

// Routes
app.use("/api/climate", climateRoutes);
app.use("/api/crops", cropRoutes);
app.use("/api/monthly-climate", monthlyClimateRoutes);
app.use("/api/alerts", alertRoutes);
app.use("/api/insights", insightRoutes);
app.use("/api/heatmap", heatmapRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api/settings", settingsRoutes);
app.use("/api/weather", weatherRoutes);
app.use("/api/field-reports", fieldReportRoutes);
app.use("/api/auth", authRoutes);

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Connect to MongoDB and start server
mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log("Connected to MongoDB");
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error("MongoDB connection error:", err);
    process.exit(1);
  });
