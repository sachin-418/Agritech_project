import { Router } from "express";
import Climate from "../models/Climate.js";

const router = Router();

// GET current climate data
router.get("/", async (req, res) => {
  try {
    const climate = await Climate.findOne().sort({ createdAt: -1 });
    if (!climate) return res.status(404).json({ message: "No climate data found" });
    res.json(climate);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST new climate data
router.post("/", async (req, res) => {
  try {
    const climate = await Climate.create(req.body);
    res.status(201).json(climate);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT update climate data
router.put("/:id", async (req, res) => {
  try {
    const climate = await Climate.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!climate) return res.status(404).json({ message: "Climate data not found" });
    res.json(climate);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

export default router;
