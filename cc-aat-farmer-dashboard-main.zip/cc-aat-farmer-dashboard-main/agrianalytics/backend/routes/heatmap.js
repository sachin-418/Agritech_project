import { Router } from "express";
import Heatmap from "../models/Heatmap.js";

const router = Router();

// GET all heatmap data
router.get("/", async (req, res) => {
  try {
    const data = await Heatmap.find().sort({ temp: 1, rain: 1 });
    res.json(data);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
