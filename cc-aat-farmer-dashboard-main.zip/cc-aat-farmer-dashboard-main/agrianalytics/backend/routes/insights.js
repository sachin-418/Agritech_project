import { Router } from "express";
import Insight from "../models/Insight.js";

const router = Router();

// GET all insights
router.get("/", async (req, res) => {
  try {
    const insights = await Insight.find().sort({ createdAt: -1 });
    res.json(insights);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST new insight
router.post("/", async (req, res) => {
  try {
    const insight = await Insight.create(req.body);
    res.status(201).json(insight);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

export default router;
