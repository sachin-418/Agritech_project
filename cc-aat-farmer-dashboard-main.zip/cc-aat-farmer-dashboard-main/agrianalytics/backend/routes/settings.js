import { Router } from "express";
import Settings from "../models/Settings.js";

const router = Router();

// GET all settings
router.get("/", async (req, res) => {
  try {
    const settings = await Settings.find();
    res.json(settings);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT update a settings section
router.put("/:id", async (req, res) => {
  try {
    const setting = await Settings.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!setting) return res.status(404).json({ message: "Settings section not found" });
    res.json(setting);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

export default router;
