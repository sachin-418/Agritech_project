import { Router } from "express";
import Alert from "../models/Alert.js";

const router = Router();

// GET all active alerts
router.get("/", async (req, res) => {
  try {
    const alerts = await Alert.find({ active: true }).sort({ createdAt: -1 });
    res.json(alerts);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST new alert
router.post("/", async (req, res) => {
  try {
    const alert = await Alert.create(req.body);
    res.status(201).json(alert);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT dismiss alert
router.put("/:id/dismiss", async (req, res) => {
  try {
    const alert = await Alert.findByIdAndUpdate(req.params.id, { active: false }, { new: true });
    if (!alert) return res.status(404).json({ message: "Alert not found" });
    res.json(alert);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
