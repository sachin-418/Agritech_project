import { Router } from "express";
import Analytics from "../models/Analytics.js";

const router = Router();

// GET all analytics metrics
router.get("/", async (req, res) => {
  try {
    const metrics = await Analytics.find();
    res.json(metrics);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT update analytics metric
router.put("/:id", async (req, res) => {
  try {
    const metric = await Analytics.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!metric) return res.status(404).json({ message: "Metric not found" });
    res.json(metric);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

export default router;
