import { Router } from "express";

const router = Router();

// Weather route - placeholder until API key is provided
// Will integrate with a weather API (OpenWeatherMap, WeatherAPI, etc.)
router.get("/current", async (req, res) => {
  try {
    const apiKey = process.env.WEATHER_API_KEY;
    if (!apiKey) {
      // Return mock data when no API key is configured
      return res.json({
        temperature: 28,
        condition: "Partly Cloudy",
        windSpeed: "12 km/h",
        visibility: "10 km",
        sunrise: "6:12 AM",
        sunset: "6:45 PM",
      });
    }

    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=Chennai&units=metric&appid=${encodeURIComponent(apiKey)}`
    );
    const data = await response.json();
    if (data.cod !== 200) return res.status(data.cod).json({ message: data.message });

    const toTime = (ts) => new Date(ts * 1000).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });

    res.json({
      temperature: Math.round(data.main.temp),
      condition: data.weather[0].description,
      windSpeed: `${data.wind.speed} km/h`,
      visibility: `${(data.visibility / 1000).toFixed(1)} km`,
      humidity: data.main.humidity,
      feelsLike: Math.round(data.main.feels_like),
      sunrise: toTime(data.sys.sunrise),
      sunset: toTime(data.sys.sunset),
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET 7-day forecast
router.get("/forecast", async (req, res) => {
  try {
    const apiKey = process.env.WEATHER_API_KEY;
    if (!apiKey) {
      // Return mock forecast when no API key is configured
      return res.json([
        { day: "Today", condition: "Sunny", high: 32, low: 24, rain: 10 },
        { day: "Tue", condition: "Cloudy", high: 30, low: 23, rain: 25 },
        { day: "Wed", condition: "Drizzle", high: 28, low: 22, rain: 60 },
        { day: "Thu", condition: "Rain", high: 26, low: 21, rain: 80 },
        { day: "Fri", condition: "Drizzle", high: 27, low: 22, rain: 45 },
        { day: "Sat", condition: "Cloudy", high: 29, low: 23, rain: 20 },
        { day: "Sun", condition: "Sunny", high: 31, low: 24, rain: 5 },
      ]);
    }

    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?q=Chennai&units=metric&appid=${encodeURIComponent(apiKey)}`
    );
    const data = await response.json();
    if (data.cod !== "200") return res.status(Number(data.cod)).json({ message: data.message });

    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const dailyMap = new Map();

    for (const item of data.list) {
      const date = new Date(item.dt * 1000);
      const dayKey = date.toDateString();
      if (!dailyMap.has(dayKey)) {
        dailyMap.set(dayKey, {
          day: days[date.getDay()],
          condition: item.weather[0].main,
          high: item.main.temp_max,
          low: item.main.temp_min,
          rain: Math.round((item.pop || 0) * 100),
        });
      } else {
        const existing = dailyMap.get(dayKey);
        existing.high = Math.max(existing.high, item.main.temp_max);
        existing.low = Math.min(existing.low, item.main.temp_min);
      }
    }

    const forecast = Array.from(dailyMap.values()).slice(0, 7);
    if (forecast.length > 0) forecast[0].day = "Today";

    res.json(forecast);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
