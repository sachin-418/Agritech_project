import { Router } from "express";
import MonthlyClimate from "../models/MonthlyClimate.js";

const router = Router();

// GET all monthly climate data
router.get("/", async (req, res) => {
  try {
    const { year } = req.query;
    const filter = year ? { year: Number(year) } : {};
    const data = await MonthlyClimate.find(filter).sort({ _id: 1 });
    res.json(data);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST new monthly data
router.post("/", async (req, res) => {
  try {
    const data = await MonthlyClimate.create(req.body);
    res.status(201).json(data);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

export default router;
