import { Router } from "express";
import FieldReport from "../models/FieldReport.js";

const router = Router();

// GET all field reports
router.get("/", async (req, res) => {
  try {
    const reports = await FieldReport.find().sort({ createdAt: -1 });
    res.json(reports);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST new field report
router.post("/", async (req, res) => {
  try {
    const report = await FieldReport.create(req.body);
    res.status(201).json(report);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE a field report
router.delete("/:id", async (req, res) => {
  try {
    const report = await FieldReport.findByIdAndDelete(req.params.id);
    if (!report) return res.status(404).json({ message: "Report not found" });
    res.json({ message: "Report deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
