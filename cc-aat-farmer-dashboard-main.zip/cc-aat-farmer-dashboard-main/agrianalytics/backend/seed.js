import "dotenv/config";
import mongoose from "mongoose";
import Climate from "./models/Climate.js";
import Crop from "./models/Crop.js";
import MonthlyClimate from "./models/MonthlyClimate.js";
import Alert from "./models/Alert.js";
import Insight from "./models/Insight.js";
import Heatmap from "./models/Heatmap.js";
import Analytics from "./models/Analytics.js";
import Settings from "./models/Settings.js";

const MONGODB_URI = process.env.MONGODB_URI;

async function seed() {
  await mongoose.connect(MONGODB_URI);
  console.log("Connected to MongoDB for seeding...");

  // Clear existing data
  await Promise.all([
    Climate.deleteMany(),
    Crop.deleteMany(),
    MonthlyClimate.deleteMany(),
    Alert.deleteMany(),
    Insight.deleteMany(),
    Heatmap.deleteMany(),
    Analytics.deleteMany(),
    Settings.deleteMany(),
  ]);
  console.log("Cleared existing data.");

  // 1. Climate data
  await Climate.create({
    temperature: 28,
    humidity: 75,
    rainfall: 820,
    climateRisk: "Moderate",
    suitabilityScore: 87,
    recommendedCrop: "Rice",
    confidence: 94,
    temperatureMatch: 92,
    rainfallMatch: 88,
    humidityMatch: 78,
    soilMatch: 85,
  });
  console.log("Seeded climate data.");

  // 2. Crops (merged from crops page + stability data)
  await Crop.insertMany([
    { name: "Rice", season: "Kharif", waterReq: "High", tempRange: "20-35°C", status: "Optimal", stability: 92, stdDev: 3.2, confidence: 95 },
    { name: "Wheat", season: "Rabi", waterReq: "Medium", tempRange: "15-25°C", status: "Good", stability: 85, stdDev: 4.1, confidence: 89 },
    { name: "Maize", season: "Kharif", waterReq: "Medium", tempRange: "18-32°C", status: "Moderate", stability: 78, stdDev: 5.5, confidence: 82 },
    { name: "Soybean", season: "Kharif", waterReq: "Medium", tempRange: "20-30°C", status: "Good", stability: 74, stdDev: 6.2, confidence: 78 },
    { name: "Cotton", season: "Kharif", waterReq: "Low", tempRange: "25-35°C", status: "At Risk", stability: 68, stdDev: 7.8, confidence: 72 },
    { name: "Sugarcane", season: "Annual", waterReq: "High", tempRange: "20-35°C", status: "Moderate", stability: 65, stdDev: 8.1, confidence: 70 },
    { name: "Barley", season: "Rabi", waterReq: "Low", tempRange: "12-25°C", status: "Good", stability: 60, stdDev: 9.0, confidence: 65 },
  ]);
  console.log("Seeded crops data.");

  // 3. Monthly climate data
  await MonthlyClimate.insertMany([
    { month: "Jan", avgTemp: 22, rainfall: 45 },
    { month: "Feb", avgTemp: 24, rainfall: 38 },
    { month: "Mar", avgTemp: 27, rainfall: 62 },
    { month: "Apr", avgTemp: 30, rainfall: 85 },
    { month: "May", avgTemp: 33, rainfall: 120 },
    { month: "Jun", avgTemp: 32, rainfall: 210 },
    { month: "Jul", avgTemp: 29, rainfall: 280 },
    { month: "Aug", avgTemp: 28, rainfall: 260 },
    { month: "Sep", avgTemp: 28, rainfall: 180 },
    { month: "Oct", avgTemp: 26, rainfall: 95 },
    { month: "Nov", avgTemp: 24, rainfall: 55 },
    { month: "Dec", avgTemp: 22, rainfall: 40 },
  ]);
  console.log("Seeded monthly climate data.");

  // 4. Alerts
  await Alert.insertMany([
    { text: "Heat wave expected in next 7 days", severity: "warning", icon: "TrendingUp" },
    { text: "Rainfall below seasonal average", severity: "danger", icon: "TrendingDown" },
    { text: "Humidity levels optimal for rice cultivation", severity: "success", icon: "Thermometer" },
  ]);
  console.log("Seeded alerts.");

  // 5. AI Insights
  await Insight.insertMany([
    { title: "Optimal planting window for Rice starts in 12 days", confidence: 92, category: "Timing" },
    { title: "Soil moisture levels suggest reducing irrigation by 15%", confidence: 87, category: "Water" },
    { title: "Pest risk elevated for Cotton in southern zones", confidence: 78, category: "Risk" },
    { title: "Wheat yield expected to increase 6% with current conditions", confidence: 85, category: "Yield" },
  ]);
  console.log("Seeded AI insights.");

  // 6. Heatmap data
  const crops = ["Rice", "Wheat", "Maize", "Soybean", "Cotton"];
  const heatmapEntries = [];
  for (let t = 15; t <= 40; t += 5) {
    for (let r = 200; r <= 1200; r += 200) {
      const score = Math.max(10, Math.min(100, Math.round(
        80 - Math.abs(t - 28) * 3 - Math.abs(r - 800) * 0.02 + (Math.random() * 15 - 7)
      )));
      heatmapEntries.push({
        temp: t,
        rain: r,
        score,
        crop: crops[Math.floor(Math.random() * crops.length)],
      });
    }
  }
  await Heatmap.insertMany(heatmapEntries);
  console.log("Seeded heatmap data.");

  // 7. Analytics metrics
  await Analytics.insertMany([
    { label: "Yield Prediction", value: "4.2 t/ha", change: "+8%", icon: "TrendingUp" },
    { label: "Risk Score", value: "Low", change: "-12%", icon: "Activity" },
    { label: "Data Points", value: "14.2K", change: "+340", icon: "BarChart3" },
    { label: "Model Accuracy", value: "94.2%", change: "+1.2%", icon: "PieChart" },
  ]);
  console.log("Seeded analytics metrics.");

  // 8. Settings
  await Settings.insertMany([
    {
      section: "General",
      items: [
        { label: "Region", value: "South Asia" },
        { label: "Unit System", value: "Metric" },
        { label: "Language", value: "English" },
      ],
    },
    {
      section: "Notifications",
      items: [
        { label: "Climate Alerts", value: "Enabled" },
        { label: "Crop Recommendations", value: "Enabled" },
        { label: "Weekly Reports", value: "Disabled" },
      ],
    },
    {
      section: "Data Sources",
      items: [
        { label: "Weather API", value: "Connected" },
        { label: "Soil Database", value: "Connected" },
        { label: "Satellite Imagery", value: "Pending" },
      ],
    },
    {
      section: "Security",
      items: [
        { label: "Two-Factor Auth", value: "Enabled" },
        { label: "API Key", value: "••••••••" },
        { label: "Last Login", value: "2 hours ago" },
      ],
    },
  ]);
  console.log("Seeded settings.");

  console.log("\nDatabase seeded successfully!");
  await mongoose.disconnect();
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed error:", err);
  process.exit(1);
});
