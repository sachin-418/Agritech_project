import mongoose from "mongoose";

const insightSchema = new mongoose.Schema({
  title: { type: String, required: true },
  confidence: { type: Number, min: 0, max: 100, required: true },
  category: { type: String, enum: ["Timing", "Water", "Risk", "Yield", "General"], required: true },
}, { timestamps: true });

export default mongoose.model("Insight", insightSchema);
