import mongoose from "mongoose";

const monthlyClimateSchema = new mongoose.Schema({
  month: { type: String, required: true },
  avgTemp: { type: Number, required: true },
  rainfall: { type: Number, required: true },
  year: { type: Number, default: () => new Date().getFullYear() },
}, { timestamps: true });

export default mongoose.model("MonthlyClimate", monthlyClimateSchema);
