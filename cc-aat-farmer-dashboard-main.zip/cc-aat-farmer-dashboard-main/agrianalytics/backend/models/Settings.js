import mongoose from "mongoose";

const settingsSchema = new mongoose.Schema({
  section: { type: String, required: true },
  items: [{
    label: { type: String, required: true },
    value: { type: String, required: true },
  }],
}, { timestamps: true });

export default mongoose.model("Settings", settingsSchema);
