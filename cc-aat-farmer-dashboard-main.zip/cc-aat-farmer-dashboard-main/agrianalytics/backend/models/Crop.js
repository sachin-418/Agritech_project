import mongoose from "mongoose";

const cropSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  season: { type: String, required: true },
  waterReq: { type: String, enum: ["Low", "Medium", "High"], required: true },
  tempRange: { type: String, required: true },
  status: { type: String, enum: ["Optimal", "Good", "Moderate", "At Risk"], required: true },
  stability: { type: Number, min: 0, max: 100 },
  stdDev: { type: Number },
  confidence: { type: Number, min: 0, max: 100 },
}, { timestamps: true });

export default mongoose.model("Crop", cropSchema);
