import mongoose from "mongoose";

const climateSchema = new mongoose.Schema({
  temperature: { type: Number, required: true },
  humidity: { type: Number, required: true },
  rainfall: { type: Number, required: true },
  climateRisk: { type: String, enum: ["Low", "Moderate", "High"], required: true },
  suitabilityScore: { type: Number, min: 0, max: 100, required: true },
  recommendedCrop: { type: String, required: true },
  confidence: { type: Number, min: 0, max: 100, required: true },
  temperatureMatch: { type: Number, min: 0, max: 100 },
  rainfallMatch: { type: Number, min: 0, max: 100 },
  humidityMatch: { type: Number, min: 0, max: 100 },
  soilMatch: { type: Number, min: 0, max: 100 },
}, { timestamps: true });

export default mongoose.model("Climate", climateSchema);
