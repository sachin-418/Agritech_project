import mongoose from "mongoose";

const fieldReportSchema = new mongoose.Schema({
  farmerName: { type: String, required: true },
  location: { type: String, required: true },
  cropName: { type: String, required: true },
  soilMoisture: { type: String, enum: ["Dry", "Moderate", "Wet", "Waterlogged"], required: true },
  cropHealth: { type: String, enum: ["Excellent", "Good", "Fair", "Poor"], required: true },
  pestIssues: { type: String, default: "None" },
  notes: { type: String, default: "" },
}, { timestamps: true });

export default mongoose.model("FieldReport", fieldReportSchema);
