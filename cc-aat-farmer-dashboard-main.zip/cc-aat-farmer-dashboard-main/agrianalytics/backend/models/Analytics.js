import mongoose from "mongoose";

const analyticsSchema = new mongoose.Schema({
  label: { type: String, required: true },
  value: { type: String, required: true },
  change: { type: String, required: true },
  icon: { type: String, required: true },
}, { timestamps: true });

export default mongoose.model("Analytics", analyticsSchema);
