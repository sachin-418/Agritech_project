import mongoose from "mongoose";

const alertSchema = new mongoose.Schema({
  text: { type: String, required: true },
  severity: { type: String, enum: ["warning", "danger", "success", "info"], required: true },
  icon: { type: String, required: true },
  active: { type: Boolean, default: true },
}, { timestamps: true });

export default mongoose.model("Alert", alertSchema);
