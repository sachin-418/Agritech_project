import mongoose from "mongoose";

const heatmapSchema = new mongoose.Schema({
  temp: { type: Number, required: true },
  rain: { type: Number, required: true },
  score: { type: Number, min: 0, max: 100, required: true },
  crop: { type: String, required: true },
});

export default mongoose.model("Heatmap", heatmapSchema);
