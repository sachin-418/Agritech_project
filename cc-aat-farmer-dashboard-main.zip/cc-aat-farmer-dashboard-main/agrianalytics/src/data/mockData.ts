export const mockClimateData = {
  temperature: 28,
  humidity: 75,
  rainfall: 820,
  climateRisk: "Moderate",
  suitabilityScore: 87,
  recommendedCrop: "Rice",
  confidence: 94,
  temperatureMatch: 92,
  rainfallMatch: 88,
  humidityMatch: 78,
  soilMatch: 85,
};

export const cropStabilityData = [
  { crop: "Rice", stability: 92, stdDev: 3.2, confidence: 95 },
  { crop: "Wheat", stability: 85, stdDev: 4.1, confidence: 89 },
  { crop: "Maize", stability: 78, stdDev: 5.5, confidence: 82 },
  { crop: "Soybean", stability: 74, stdDev: 6.2, confidence: 78 },
  { crop: "Cotton", stability: 68, stdDev: 7.8, confidence: 72 },
  { crop: "Sugarcane", stability: 65, stdDev: 8.1, confidence: 70 },
  { crop: "Barley", stability: 60, stdDev: 9.0, confidence: 65 },
];

export const radarData = [
  { metric: "Temperature", value: 92, fullMark: 100 },
  { metric: "Rainfall", value: 88, fullMark: 100 },
  { metric: "Humidity", value: 78, fullMark: 100 },
  { metric: "Soil", value: 85, fullMark: 100 },
];

export const heatmapData: { temp: number; rain: number; score: number; crop: string }[] = [];

const crops = ["Rice", "Wheat", "Maize", "Soybean", "Cotton"];
for (let t = 15; t <= 40; t += 5) {
  for (let r = 200; r <= 1200; r += 200) {
    const score = Math.max(10, Math.min(100, Math.round(
      80 - Math.abs(t - 28) * 3 - Math.abs(r - 800) * 0.02 + (Math.random() * 15 - 7)
    )));
    heatmapData.push({
      temp: t,
      rain: r,
      score,
      crop: crops[Math.floor(Math.random() * crops.length)],
    });
  }
}
