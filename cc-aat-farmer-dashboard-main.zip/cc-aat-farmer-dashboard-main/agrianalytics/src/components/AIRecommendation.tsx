import { useQuery } from "@tanstack/react-query";
import { fetchClimate } from "@/lib/api";
import { Sparkles, Check } from "lucide-react";

export function AIRecommendation() {
  const { data: climate, isLoading } = useQuery({ queryKey: ["climate"], queryFn: fetchClimate });

  const bullets = [
    { label: "Temperature Match", value: climate ? `${climate.temperatureMatch}%` : "—" },
    { label: "Rainfall Match", value: climate ? `${climate.rainfallMatch}%` : "—" },
    { label: "Humidity Match", value: climate ? `${climate.humidityMatch}%` : "—" },
    { label: "Soil Compatibility", value: climate ? `${climate.soilMatch}%` : "—" },
  ];

  return (
    <div className={`glass-card glow-pulse p-6 border-primary/20 animate-slide-up ${isLoading ? "opacity-50" : ""}`} style={{ animationDelay: "640ms" }}>
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
          <Sparkles className="w-4 h-4 text-primary" />
        </div>
        <h3 className="text-sm font-semibold text-foreground">AI Recommendation</h3>
      </div>

      <div className="mb-4">
        <p className="text-2xl font-bold text-primary">{climate?.recommendedCrop ?? "—"}</p>
        <p className="text-xs text-muted-foreground mt-1">
          Confidence: <span className="text-primary font-medium">{climate?.confidence ?? 0}%</span>
        </p>
      </div>

      <div className="space-y-2.5">
        {bullets.map((b) => (
          <div key={b.label} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Check className="w-3.5 h-3.5 text-primary" />
              <span className="text-xs text-muted-foreground">{b.label}</span>
            </div>
            <span className="text-xs font-mono text-foreground">{b.value}</span>
          </div>
        ))}
      </div>

      {/* Progress bar */}
      <div className="mt-5">
        <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
          <span>Overall Confidence</span>
          <span>{climate?.confidence ?? 0}%</span>
        </div>
        <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all duration-700"
            style={{ width: `${climate?.confidence ?? 0}%` }}
          />
        </div>
      </div>
    </div>
  );
}
