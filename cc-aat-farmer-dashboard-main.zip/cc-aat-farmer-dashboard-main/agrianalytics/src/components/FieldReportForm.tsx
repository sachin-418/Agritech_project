import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchFieldReports, createFieldReport, deleteFieldReport } from "@/lib/api";
import { ClipboardList, Send, Trash2, MapPin, User, Sprout } from "lucide-react";

const emptyForm = {
  farmerName: "",
  location: "",
  cropName: "",
  soilMoisture: "Moderate",
  cropHealth: "Good",
  pestIssues: "None",
  notes: "",
};

export function FieldReportForm() {
  const queryClient = useQueryClient();
  const [form, setForm] = useState(emptyForm);
  const { data: reports = [] } = useQuery({ queryKey: ["field-reports"], queryFn: fetchFieldReports });

  const addMutation = useMutation({
    mutationFn: createFieldReport,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-reports"] });
      setForm(emptyForm);
    },
  });

  const delMutation = useMutation({
    mutationFn: deleteFieldReport,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["field-reports"] }),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.farmerName.trim() || !form.location.trim() || !form.cropName.trim()) return;
    addMutation.mutate(form);
  };

  const set = (key: string, val: string) => setForm((p) => ({ ...p, [key]: val }));

  const healthColor = (h: string) =>
    h === "Excellent" ? "text-primary" : h === "Good" ? "text-primary/70" : h === "Fair" ? "text-[hsl(var(--warning))]" : "text-destructive";

  return (
    <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: "720ms" }}>
      <div className="flex items-center gap-2 mb-5">
        <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
          <ClipboardList className="w-4 h-4 text-primary" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-foreground">Field Report</h3>
          <p className="text-[10px] text-muted-foreground">Submit your daily field observations</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
              <User className="w-3 h-3" /> Farmer Name *
            </label>
            <input
              type="text"
              value={form.farmerName}
              onChange={(e) => set("farmerName", e.target.value)}
              placeholder="Your name"
              className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
              required
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
              <MapPin className="w-3 h-3" /> Location *
            </label>
            <input
              type="text"
              value={form.location}
              onChange={(e) => set("location", e.target.value)}
              placeholder="Village / District"
              className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
              required
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
              <Sprout className="w-3 h-3" /> Crop *
            </label>
            <input
              type="text"
              value={form.cropName}
              onChange={(e) => set("cropName", e.target.value)}
              placeholder="e.g. Rice, Wheat"
              className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
              required
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Soil Moisture</label>
            <select
              value={form.soilMoisture}
              onChange={(e) => set("soilMoisture", e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            >
              <option value="Dry">Dry</option>
              <option value="Moderate">Moderate</option>
              <option value="Wet">Wet</option>
              <option value="Waterlogged">Waterlogged</option>
            </select>
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Crop Health</label>
            <select
              value={form.cropHealth}
              onChange={(e) => set("cropHealth", e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            >
              <option value="Excellent">Excellent</option>
              <option value="Good">Good</option>
              <option value="Fair">Fair</option>
              <option value="Poor">Poor</option>
            </select>
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Pest / Disease Issues</label>
            <input
              type="text"
              value={form.pestIssues}
              onChange={(e) => set("pestIssues", e.target.value)}
              placeholder="None, Aphids, Blight..."
              className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Notes</label>
          <textarea
            value={form.notes}
            onChange={(e) => set("notes", e.target.value)}
            rows={2}
            placeholder="Additional observations (weather, irrigation, yield estimate...)"
            className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
          />
        </div>
        <button
          type="submit"
          disabled={addMutation.isPending}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
        >
          <Send className="w-3.5 h-3.5" />
          {addMutation.isPending ? "Submitting..." : "Submit Report"}
        </button>
        {addMutation.isError && (
          <p className="text-xs text-destructive">{addMutation.error.message}</p>
        )}
      </form>

      {/* Recent reports */}
      {reports.length > 0 && (
        <div className="mt-5 pt-4 border-t border-border/40">
          <h4 className="text-xs font-semibold text-muted-foreground mb-3">Recent Reports</h4>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {reports.slice(0, 5).map((r) => (
              <div key={r._id} className="flex items-start justify-between p-3 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-colors">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-medium text-foreground">{r.farmerName}</span>
                    <span className="text-muted-foreground">•</span>
                    <span className="text-muted-foreground">{r.location}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1 text-[10px]">
                    <span className="text-foreground">{r.cropName}</span>
                    <span className="text-muted-foreground">|</span>
                    <span className={healthColor(r.cropHealth)}>{r.cropHealth}</span>
                    <span className="text-muted-foreground">|</span>
                    <span className="text-muted-foreground">Soil: {r.soilMoisture}</span>
                  </div>
                  {r.notes && <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{r.notes}</p>}
                </div>
                <button
                  onClick={() => delMutation.mutate(r._id)}
                  className="p-1 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors ml-2 shrink-0"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
