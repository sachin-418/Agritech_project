import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
} from "recharts";
import { radarData } from "@/data/mockData";

interface Props {
  suitabilityScore: number;
  adjustments: { temp: number; rain: number; humidity: number };
}

export function CropSuitability({ suitabilityScore, adjustments }: Props) {
  const adjustedData = radarData.map((d) => {
    let mod = 0;
    if (d.metric === "Temperature") mod = -Math.abs(adjustments.temp) * 2;
    if (d.metric === "Rainfall") mod = -Math.abs(adjustments.rain) * 0.5;
    if (d.metric === "Humidity") mod = -Math.abs(adjustments.humidity) * 0.8;
    return { ...d, value: Math.max(0, Math.min(100, d.value + mod)) };
  });

  const riskLevel =
    suitabilityScore >= 75 ? "Safe" : suitabilityScore >= 50 ? "Moderate" : "High Risk";
  const riskColor =
    suitabilityScore >= 75 ? "bg-primary/20 text-primary" : suitabilityScore >= 50 ? "bg-warning/20 text-warning" : "bg-danger/20 text-danger";

  const circumference = 2 * Math.PI * 58;
  const offset = circumference - (suitabilityScore / 100) * circumference;

  return (
    <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: "320ms" }}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-foreground">Crop Suitability</h3>
        <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${riskColor}`}>{riskLevel}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        {/* Radar */}
        <ResponsiveContainer width="100%" height={220}>
          <RadarChart data={adjustedData} cx="50%" cy="50%" outerRadius="70%">
            <PolarGrid stroke="hsl(150 10% 20%)" />
            <PolarAngleAxis
              dataKey="metric"
              tick={{ fill: "hsl(150 8% 55%)", fontSize: 11 }}
            />
            <PolarRadiusAxis tick={false} axisLine={false} />
            <Radar
              dataKey="value"
              stroke="hsl(152 60% 45%)"
              fill="hsl(152 60% 45%)"
              fillOpacity={0.15}
              strokeWidth={2}
            />
          </RadarChart>
        </ResponsiveContainer>

        {/* Gauge */}
        <div className="flex flex-col items-center">
          <div className="relative w-36 h-36">
            <svg viewBox="0 0 128 128" className="w-full h-full -rotate-90">
              <circle
                cx="64" cy="64" r="58"
                fill="none"
                stroke="hsl(150 10% 15%)"
                strokeWidth="8"
              />
              <circle
                cx="64" cy="64" r="58"
                fill="none"
                stroke="hsl(152 60% 45%)"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={offset}
                className="transition-all duration-700 ease-out"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold text-foreground">{suitabilityScore}</span>
              <span className="text-xs text-muted-foreground">/ 100</span>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2">Overall Score</p>
        </div>
      </div>
    </div>
  );
}
