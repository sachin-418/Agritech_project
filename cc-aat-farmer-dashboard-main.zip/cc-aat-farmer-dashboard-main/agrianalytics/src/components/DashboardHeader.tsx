import { Bell, Search } from "lucide-react";

export function DashboardHeader() {
  return (
    <header className="h-16 border-b border-border flex items-center justify-between px-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground">Climate Dashboard</h2>
        <p className="text-xs text-muted-foreground">Real-time crop intelligence · Updated just now</p>
      </div>
      <div className="flex items-center gap-3">
        <button className="w-9 h-9 rounded-xl bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
          <Search className="w-4 h-4" />
        </button>
        <button className="w-9 h-9 rounded-xl bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors relative">
          <Bell className="w-4 h-4" />
          <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-primary rounded-full border-2 border-background" />
        </button>
        <div className="w-9 h-9 rounded-xl bg-primary/20 flex items-center justify-center text-primary text-sm font-bold">
          A
        </div>
      </div>
    </header>
  );
}
