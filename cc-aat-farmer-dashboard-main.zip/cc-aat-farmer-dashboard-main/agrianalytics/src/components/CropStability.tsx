import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { useQuery } from "@tanstack/react-query";
import { fetchCrops } from "@/lib/api";

export function CropStability() {
  const { data: crops, isLoading } = useQuery({ queryKey: ["crops"], queryFn: fetchCrops });

  const stabilityData = (crops ?? []).filter(c => c.stability != null).map(c => ({
    crop: c.name,
    stability: c.stability,
    stdDev: c.stdDev,
    confidence: c.confidence,
  }));

  return (
    <div className={`glass-card p-6 animate-slide-up ${isLoading ? "opacity-50" : ""}`} style={{ animationDelay: "480ms" }}>
      <h3 className="text-sm font-semibold text-foreground mb-4">Crop Stability Index</h3>
      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={stabilityData} layout="vertical" margin={{ left: 10, right: 20 }}>
          <XAxis type="number" domain={[0, 100]} tick={{ fill: "hsl(150 8% 55%)", fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis type="category" dataKey="crop" tick={{ fill: "hsl(150 8% 55%)", fontSize: 12 }} axisLine={false} tickLine={false} width={75} />
          <Tooltip
            contentStyle={{
              backgroundColor: "hsl(150 15% 10%)",
              border: "1px solid hsl(150 10% 20%)",
              borderRadius: "12px",
              fontSize: "12px",
              color: "#ffffff",
            }}
            itemStyle={{ color: "#ffffff" }}
            labelStyle={{ color: "#e5e5e5" }}
            formatter={(value: number, _name: string, props: any) => [
              `Score: ${value} | StdDev: ${props.payload.stdDev} | Confidence: ${props.payload.confidence}%`,
              "",
            ]}
          />
          <Bar dataKey="stability" radius={[0, 6, 6, 0]} barSize={20}>
            {stabilityData.map((entry, index) => (
              <Cell
                key={entry.crop}
                fill={index === 0 ? "hsl(152 60% 45%)" : "hsl(152 40% 25%)"}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
