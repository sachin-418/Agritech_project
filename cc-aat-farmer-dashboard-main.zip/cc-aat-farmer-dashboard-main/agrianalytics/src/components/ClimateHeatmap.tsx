import { useQuery } from "@tanstack/react-query";
import { fetchHeatmap } from "@/lib/api";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

export function ClimateHeatmap() {
  const { data: heatmapData = [], isLoading } = useQuery({ queryKey: ["heatmap"], queryFn: fetchHeatmap });

  const temps = [...new Set(heatmapData.map((d) => d.temp))].sort((a, b) => a - b);
  const rains = [...new Set(heatmapData.map((d) => d.rain))].sort((a, b) => a - b);

  const getColor = (score: number) => {
    if (score >= 80) return "bg-primary/70";
    if (score >= 60) return "bg-primary/40";
    if (score >= 40) return "bg-warning/40";
    if (score >= 20) return "bg-danger/40";
    return "bg-danger/20";
  };

  return (
    <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: "560ms" }}>
      <h3 className="text-sm font-semibold text-foreground mb-4">Climate Risk Heatmap</h3>

      <div className="overflow-x-auto">
        <div className="inline-grid gap-1" style={{ gridTemplateColumns: `60px repeat(${temps.length}, 1fr)` }}>
          {/* Header */}
          <div />
          {temps.map((t) => (
            <div key={t} className="text-[10px] text-muted-foreground text-center">{t}°C</div>
          ))}

          {/* Rows */}
          {rains.map((r) => (
            <>
              <div key={`label-${r}`} className="text-[10px] text-muted-foreground flex items-center">{r}mm</div>
              {temps.map((t) => {
                const cell = heatmapData.find((d) => d.temp === t && d.rain === r);
                if (!cell) return <div key={`${t}-${r}`} />;
                return (
                  <Tooltip key={`${t}-${r}`}>
                    <TooltipTrigger asChild>
                      <div
                        className={`w-full aspect-square rounded-md ${getColor(cell.score)} cursor-pointer transition-all duration-200 hover:scale-110 min-w-[28px]`}
                      />
                    </TooltipTrigger>
                    <TooltipContent className="bg-card border-border text-white">
                      <p className="text-xs font-medium text-white">{cell.crop}</p>
                      <p className="text-xs text-gray-300">Score: {cell.score}</p>
                    </TooltipContent>
                  </Tooltip>
                );
              })}
            </>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-3 mt-4">
        <span className="text-[10px] text-muted-foreground">Low</span>
        <div className="flex gap-0.5">
          {["bg-danger/20", "bg-danger/40", "bg-warning/40", "bg-primary/40", "bg-primary/70"].map((c) => (
            <div key={c} className={`w-5 h-2.5 rounded-sm ${c}`} />
          ))}
        </div>
        <span className="text-[10px] text-muted-foreground">High</span>
      </div>
    </div>
  );
}
