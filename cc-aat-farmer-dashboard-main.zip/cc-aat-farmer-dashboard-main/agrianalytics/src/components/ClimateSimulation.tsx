import { Slider } from "@/components/ui/slider";
import { Thermometer, CloudRain, Droplets } from "lucide-react";

interface Props {
  adjustments: { temp: number; rain: number; humidity: number };
  onChange: (key: "temp" | "rain" | "humidity", value: number) => void;
}

export function ClimateSimulation({ adjustments, onChange }: Props) {
  const sliders = [
    {
      key: "temp" as const,
      label: "Temperature",
      icon: Thermometer,
      min: -5,
      max: 5,
      step: 0.5,
      unit: "°C",
      value: adjustments.temp,
    },
    {
      key: "rain" as const,
      label: "Rainfall",
      icon: CloudRain,
      min: -30,
      max: 30,
      step: 5,
      unit: "%",
      value: adjustments.rain,
    },
    {
      key: "humidity" as const,
      label: "Humidity",
      icon: Droplets,
      min: -20,
      max: 20,
      step: 2,
      unit: "%",
      value: adjustments.humidity,
    },
  ];

  return (
    <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: "400ms" }}>
      <h3 className="text-sm font-semibold text-foreground mb-5">Climate Simulation</h3>
      <div className="space-y-6">
        {sliders.map((s) => (
          <div key={s.key}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <s.icon className="w-4 h-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{s.label}</span>
              </div>
              <span className="text-xs font-mono text-primary">
                {s.value > 0 ? "+" : ""}
                {s.value}
                {s.unit}
              </span>
            </div>
            <Slider
              min={s.min}
              max={s.max}
              step={s.step}
              value={[s.value]}
              onValueChange={([v]) => onChange(s.key, v)}
              className="[&_[role=slider]]:bg-primary [&_[role=slider]]:border-primary [&_.relative>div]:bg-primary"
            />
          </div>
        ))}
      </div>
    </div>
  );
}
