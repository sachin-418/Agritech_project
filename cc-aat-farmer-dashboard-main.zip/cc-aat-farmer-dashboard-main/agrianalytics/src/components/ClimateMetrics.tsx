import { Thermometer, Droplets, CloudRain, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { fetchClimate } from "@/lib/api";

export function ClimateMetrics() {
  const { data: climate, isLoading } = useQuery({ queryKey: ["climate"], queryFn: fetchClimate });

  const metrics = [
    {
      label: "Temperature",
      value: climate ? `${climate.temperature}°C` : "—",
      icon: Thermometer,
      trend: "+2.1°",
      trendUp: true,
      color: "text-chart-3",
      bgColor: "bg-chart-3/10",
    },
    {
      label: "Humidity",
      value: climate ? `${climate.humidity}%` : "—",
      icon: Droplets,
      trend: "-3%",
      trendUp: false,
      color: "text-chart-4",
      bgColor: "bg-chart-4/10",
    },
    {
      label: "Rainfall",
      value: climate ? `${climate.rainfall}mm` : "—",
      icon: CloudRain,
      trend: "+12mm",
      trendUp: true,
      color: "text-chart-2",
      bgColor: "bg-chart-2/10",
    },
    {
      label: "Climate Risk",
      value: climate?.climateRisk ?? "—",
      icon: AlertTriangle,
      trend: "Stable",
      trendUp: false,
      color: "text-warning",
      bgColor: "bg-warning/10",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {metrics.map((m, i) => (
        <div
          key={m.label}
          className={`glass-card-hover p-5 animate-slide-up ${isLoading ? "opacity-50" : ""}`}
          style={{ animationDelay: `${i * 80}ms` }}
        >
          <div className="flex items-start justify-between">
            <div className={`w-10 h-10 rounded-xl ${m.bgColor} flex items-center justify-center`}>
              <m.icon className={`w-5 h-5 ${m.color}`} />
            </div>
            <div className="flex items-center gap-1 text-xs">
              {m.trendUp ? (
                <TrendingUp className="w-3 h-3 text-primary" />
              ) : (
                <TrendingDown className="w-3 h-3 text-muted-foreground" />
              )}
              <span className={m.trendUp ? "text-primary" : "text-muted-foreground"}>{m.trend}</span>
            </div>
          </div>
          <div className="mt-4">
            <p className="metric-value">{m.value}</p>
            <p className="metric-label mt-1">{m.label}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
