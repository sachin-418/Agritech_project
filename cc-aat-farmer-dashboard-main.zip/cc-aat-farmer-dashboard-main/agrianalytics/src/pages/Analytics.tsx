import { AppSidebar } from "@/components/AppSidebar";
import { DashboardHeader } from "@/components/DashboardHeader";
import { CropStability } from "@/components/CropStability";
import { ClimateHeatmap } from "@/components/ClimateHeatmap";
import { BarChart3, TrendingUp, Activity, PieChart } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { fetchAnalytics } from "@/lib/api";

const iconMap: Record<string, any> = { TrendingUp, Activity, BarChart3, PieChart };

const Analytics = () => {
  const { data: metrics = [] } = useQuery({ queryKey: ["analytics"], queryFn: fetchAnalytics });

  return (
    <div className="flex min-h-screen w-full">
      <AppSidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <DashboardHeader />
        <main className="flex-1 p-4 md:p-6 space-y-6 overflow-auto">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Analytics</h1>
            <p className="text-sm text-muted-foreground mt-1">Comprehensive data analysis and performance metrics</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {metrics.map((m) => {
              const Icon = iconMap[m.icon] || BarChart3;
              return (
                <div key={m.label} className="glass-card-hover p-5">
                  <div className="flex items-center justify-between mb-2">
                    <Icon className="w-4 h-4 text-primary" />
                    <span className="text-xs text-primary font-mono">{m.change}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{m.label}</p>
                  <p className="text-2xl font-bold text-foreground mt-1">{m.value}</p>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <CropStability />
            <ClimateHeatmap />
          </div>
        </main>
      </div>
    </div>
  );
};

export default Analytics;
