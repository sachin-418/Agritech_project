import { AppSidebar } from "@/components/AppSidebar";
import { DashboardHeader } from "@/components/DashboardHeader";
import { Settings as SettingsIcon, Bell, Globe, Database, Shield } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { fetchSettings } from "@/lib/api";

const sectionIcons: Record<string, any> = {
  General: SettingsIcon,
  Notifications: Bell,
  "Data Sources": Database,
  Security: Shield,
};

const Settings = () => {
  const { data: sections = [] } = useQuery({ queryKey: ["settings"], queryFn: fetchSettings });

  return (
    <div className="flex min-h-screen w-full">
      <AppSidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <DashboardHeader />
        <main className="flex-1 p-4 md:p-6 space-y-6 overflow-auto">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Settings</h1>
            <p className="text-sm text-muted-foreground mt-1">Configure your dashboard preferences</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {sections.map((section) => {
              const Icon = sectionIcons[section.section] || SettingsIcon;
              return (
                <div key={section.section} className="glass-card p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <Icon className="w-4 h-4 text-primary" />
                    <h3 className="text-sm font-semibold text-foreground">{section.section}</h3>
                  </div>
                  <div className="space-y-3">
                    {section.items.map((item) => (
                    <div key={item.label} className="flex items-center justify-between py-2 border-b border-border/30 last:border-0">
                      <span className="text-sm text-muted-foreground">{item.label}</span>
                      <span className="text-sm font-medium text-foreground">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>
              );
            })}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Settings;
