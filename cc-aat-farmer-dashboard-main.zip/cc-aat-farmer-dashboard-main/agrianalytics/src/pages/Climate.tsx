import { AppSidebar } from "@/components/AppSidebar";
import { DashboardHeader } from "@/components/DashboardHeader";
import { ClimateMetrics } from "@/components/ClimateMetrics";
import { ClimateHeatmap } from "@/components/ClimateHeatmap";
import { Thermometer, TrendingUp, TrendingDown } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { fetchMonthlyClimate, fetchAlerts } from "@/lib/api";

const iconMap: Record<string, any> = { TrendingUp, TrendingDown, Thermometer };

const Climate = () => {
  const { data: monthlyData = [] } = useQuery({ queryKey: ["monthlyClimate"], queryFn: fetchMonthlyClimate });
  const { data: alerts = [] } = useQuery({ queryKey: ["alerts"], queryFn: fetchAlerts });

  return (
    <div className="flex min-h-screen w-full">
      <AppSidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <DashboardHeader />
        <main className="flex-1 p-4 md:p-6 space-y-6 overflow-auto">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Climate Overview</h1>
            <p className="text-sm text-muted-foreground mt-1">Historical and real-time climate data analysis</p>
          </div>

          <ClimateMetrics />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="glass-card p-6">
              <h3 className="text-sm font-semibold text-foreground mb-4">Monthly Temperature Trends</h3>
              <div className="space-y-3">
                {monthlyData.map((d) => (
                  <div key={d.month} className="flex items-center gap-3">
                    <span className="text-xs text-muted-foreground w-8">{d.month}</span>
                    <div className="flex-1 bg-secondary rounded-full h-2">
                      <div
                        className="bg-primary rounded-full h-2 transition-all"
                        style={{ width: `${(d.avgTemp / 40) * 100}%` }}
                      />
                    </div>
                    <span className="text-xs font-mono text-foreground w-10 text-right">{d.avgTemp}°C</span>
                  </div>
                ))}
              </div>
            </div>

            <ClimateHeatmap />
          </div>

          <div className="glass-card p-6">
            <h3 className="text-sm font-semibold text-foreground mb-4">Climate Alerts</h3>
            <div className="space-y-3">
              {alerts.map((alert, i) => {
                const Icon = iconMap[alert.icon] || Thermometer;
                return (
                  <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-secondary/50">
                    <Icon className={`w-4 h-4 ${
                      alert.severity === "warning" ? "text-[hsl(var(--warning))]" :
                      alert.severity === "danger" ? "text-destructive" : "text-primary"
                    }`} />
                    <span className="text-sm text-foreground">{alert.text}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Climate;
