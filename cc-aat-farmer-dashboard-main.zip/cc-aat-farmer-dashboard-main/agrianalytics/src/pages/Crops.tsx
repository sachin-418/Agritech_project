import { useState } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { DashboardHeader } from "@/components/DashboardHeader";
import { CropStability } from "@/components/CropStability";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchCrops, createCrop, deleteCrop } from "@/lib/api";
import { Leaf, TrendingUp, Droplets, Thermometer, Plus, Trash2 } from "lucide-react";

const Crops = () => {
  const queryClient = useQueryClient();
  const { data: crops = [], isLoading } = useQuery({ queryKey: ["crops"], queryFn: fetchCrops });

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    name: "",
    season: "Kharif",
    waterReq: "Medium",
    tempRange: "",
    status: "Good",
  });

  const addMutation = useMutation({
    mutationFn: createCrop,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["crops"] });
      setForm({ name: "", season: "Kharif", waterReq: "Medium", tempRange: "", status: "Good" });
      setShowForm(false);
    },
  });

  const delMutation = useMutation({
    mutationFn: deleteCrop,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["crops"] }),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.tempRange.trim()) return;
    addMutation.mutate(form);
  };

  const statusColor = (s: string) =>
    s === "Optimal" ? "text-primary bg-primary/10" :
    s === "Good" ? "text-primary bg-primary/10" :
    s === "Moderate" ? "text-[hsl(var(--warning))] bg-[hsl(var(--warning))]/10" :
    "text-destructive bg-destructive/10";

  return (
    <div className="flex min-h-screen w-full">
      <AppSidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <DashboardHeader />
        <main className="flex-1 p-4 md:p-6 space-y-6 overflow-auto">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Crop Management</h1>
            <p className="text-sm text-muted-foreground mt-1">Monitor and manage crop performance across regions</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: "Active Crops", value: String(crops.length), icon: Leaf },
              { label: "Avg Stability", value: crops.length ? `${Math.round(crops.reduce((s, c) => s + (c.stability ?? 0), 0) / crops.length)}%` : "—", icon: TrendingUp },
              { label: "Water Usage", value: "Medium", icon: Droplets },
              { label: "Temp Range", value: "20-35°C", icon: Thermometer },
            ].map((m) => (
              <div key={m.label} className="glass-card-hover p-5">
                <div className="flex items-center gap-2 mb-2">
                  <m.icon className="w-4 h-4 text-primary" />
                  <span className="text-xs text-muted-foreground">{m.label}</span>
                </div>
                <p className="text-2xl font-bold text-foreground">{m.value}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground">Crop Database</h3>
              <button
                onClick={() => setShowForm(!showForm)}
                className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Crop
              </button>
            </div>

            {showForm && (
              <form onSubmit={handleSubmit} className="mb-6 p-4 rounded-xl bg-secondary/40 border border-border/50 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Crop Name *</label>
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="e.g. Millet"
                      className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Season</label>
                    <select
                      value={form.season}
                      onChange={(e) => setForm({ ...form, season: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    >
                      <option value="Kharif">Kharif</option>
                      <option value="Rabi">Rabi</option>
                      <option value="Zaid">Zaid</option>
                      <option value="Annual">Annual</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Water Requirement</label>
                    <select
                      value={form.waterReq}
                      onChange={(e) => setForm({ ...form, waterReq: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    >
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Temp Range *</label>
                    <input
                      type="text"
                      value={form.tempRange}
                      onChange={(e) => setForm({ ...form, tempRange: e.target.value })}
                      placeholder="e.g. 25-35°C"
                      className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Status</label>
                    <select
                      value={form.status}
                      onChange={(e) => setForm({ ...form, status: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg bg-background border border-border text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    >
                      <option value="Optimal">Optimal</option>
                      <option value="Good">Good</option>
                      <option value="Moderate">Moderate</option>
                      <option value="At Risk">At Risk</option>
                    </select>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    type="submit"
                    disabled={addMutation.isPending}
                    className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
                  >
                    {addMutation.isPending ? "Adding..." : "Add Crop"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="px-4 py-2 rounded-lg bg-secondary text-foreground text-xs font-medium hover:bg-secondary/80 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
                {addMutation.isError && (
                  <p className="text-xs text-destructive">{addMutation.error.message}</p>
                )}
              </form>
            )}

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium">Crop</th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium">Season</th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium">Water Req.</th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium">Temp Range</th>
                    <th className="text-left py-3 px-4 text-muted-foreground font-medium">Status</th>
                    <th className="text-right py-3 px-4 text-muted-foreground font-medium">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {crops.map((c) => (
                    <tr key={c._id} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                      <td className="py-3 px-4 text-foreground font-medium">{c.name}</td>
                      <td className="py-3 px-4 text-muted-foreground">{c.season}</td>
                      <td className="py-3 px-4 text-muted-foreground">{c.waterReq}</td>
                      <td className="py-3 px-4 text-muted-foreground font-mono text-xs">{c.tempRange}</td>
                      <td className="py-3 px-4">
                        <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${statusColor(c.status)}`}>{c.status}</span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => delMutation.mutate(c._id)}
                          className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <CropStability />
        </main>
      </div>
    </div>
  );
};

export default Crops;
