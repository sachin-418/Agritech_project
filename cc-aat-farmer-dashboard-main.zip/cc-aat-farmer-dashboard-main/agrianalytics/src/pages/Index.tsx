import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AppSidebar } from "@/components/AppSidebar";
import { DashboardHeader } from "@/components/DashboardHeader";
import { ClimateMetrics } from "@/components/ClimateMetrics";
import { CropSuitability } from "@/components/CropSuitability";
import { ClimateSimulation } from "@/components/ClimateSimulation";
import { CropStability } from "@/components/CropStability";
import { ClimateHeatmap } from "@/components/ClimateHeatmap";
import { AIRecommendation } from "@/components/AIRecommendation";
import { fetchClimate } from "@/lib/api";

const Index = () => {
  const [adjustments, setAdjustments] = useState({ temp: 0, rain: 0, humidity: 0 });
  const { data: climate } = useQuery({ queryKey: ["climate"], queryFn: fetchClimate });

  const handleChange = (key: "temp" | "rain" | "humidity", value: number) => {
    setAdjustments((prev) => ({ ...prev, [key]: value }));
  };

  const baseScore = climate?.suitabilityScore ?? 87;
  const adjustedScore = Math.max(
    0,
    Math.min(
      100,
      Math.round(
        baseScore -
          Math.abs(adjustments.temp) * 2 -
          Math.abs(adjustments.rain) * 0.3 -
          Math.abs(adjustments.humidity) * 0.4
      )
    )
  );

  return (
    <div className="flex min-h-screen w-full">
      <AppSidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <DashboardHeader />
        <main className="flex-1 p-4 md:p-6 space-y-6 overflow-auto">
          {/* Row 1: Climate Metrics */}
          <ClimateMetrics />

          {/* Row 2: Suitability + Simulation */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2">
              <CropSuitability suitabilityScore={adjustedScore} adjustments={adjustments} />
            </div>
            <ClimateSimulation adjustments={adjustments} onChange={handleChange} />
          </div>

          {/* Row 3: Stability + Heatmap + AI */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <CropStability />
            <ClimateHeatmap />
            <AIRecommendation />
          </div>
        </main>
      </div>
    </div>
  );
};

export default Index;
