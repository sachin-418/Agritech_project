import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { AppSidebar } from "@/components/AppSidebar";
import { DashboardHeader } from "@/components/DashboardHeader";
import { FieldReportForm } from "@/components/FieldReportForm";
import { fetchFieldReports, deleteFieldReport } from "@/lib/api";
import { ClipboardList, Trash2, MapPin, User, Sprout, Calendar, Bug, Droplets, HeartPulse } from "lucide-react";

const FieldReports = () => {
  const queryClient = useQueryClient();
  const { data: reports = [], isLoading } = useQuery({ queryKey: ["field-reports"], queryFn: fetchFieldReports });

  const delMutation = useMutation({
    mutationFn: deleteFieldReport,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["field-reports"] }),
  });

  const healthColor = (h: string) =>
    h === "Excellent" ? "text-primary" : h === "Good" ? "text-primary/70" : h === "Fair" ? "text-[hsl(var(--warning))]" : "text-destructive";

  const moistureColor = (m: string) =>
    m === "Wet" ? "text-blue-400" : m === "Moderate" ? "text-primary" : m === "Dry" ? "text-orange-400" : "text-destructive";

  return (
    <div className="flex min-h-screen w-full">
      <AppSidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <DashboardHeader />
        <main className="flex-1 p-4 md:p-6 space-y-6 overflow-auto">
          {/* Page Header */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <ClipboardList className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-foreground">Field Reports</h2>
              <p className="text-xs text-muted-foreground">Submit and view farmer field observations</p>
            </div>
          </div>

          {/* Submit Form */}
          <FieldReportForm />

          {/* All Reports */}
          <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: "200ms" }}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-sm font-semibold text-foreground">All Reports</h3>
              <span className="text-xs text-muted-foreground">{reports.length} total</span>
            </div>

            {isLoading ? (
              <p className="text-sm text-muted-foreground">Loading reports...</p>
            ) : reports.length === 0 ? (
              <p className="text-sm text-muted-foreground">No field reports submitted yet.</p>
            ) : (
              <div className="space-y-3">
                {reports.map((r) => (
                  <div
                    key={r._id}
                    className="p-4 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-colors border border-border/30"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0 space-y-2">
                        {/* Header row */}
                        <div className="flex items-center gap-3 flex-wrap">
                          <span className="flex items-center gap-1.5 text-sm font-medium text-foreground">
                            <User className="w-3.5 h-3.5 text-muted-foreground" />
                            {r.farmerName}
                          </span>
                          <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <MapPin className="w-3 h-3" />
                            {r.location}
                          </span>
                          <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <Calendar className="w-3 h-3" />
                            {new Date(r.createdAt).toLocaleDateString()}
                          </span>
                        </div>

                        {/* Details row */}
                        <div className="flex items-center gap-4 flex-wrap text-xs">
                          <span className="flex items-center gap-1">
                            <Sprout className="w-3 h-3 text-primary" />
                            <span className="text-foreground font-medium">{r.cropName}</span>
                          </span>
                          <span className="flex items-center gap-1">
                            <HeartPulse className="w-3 h-3" />
                            <span className={healthColor(r.cropHealth)}>{r.cropHealth}</span>
                          </span>
                          <span className="flex items-center gap-1">
                            <Droplets className="w-3 h-3" />
                            <span className={moistureColor(r.soilMoisture)}>{r.soilMoisture}</span>
                          </span>
                          {r.pestIssues && r.pestIssues !== "None" && (
                            <span className="flex items-center gap-1 text-destructive">
                              <Bug className="w-3 h-3" />
                              {r.pestIssues}
                            </span>
                          )}
                        </div>

                        {/* Notes */}
                        {r.notes && (
                          <p className="text-xs text-muted-foreground mt-1">{r.notes}</p>
                        )}
                      </div>

                      <button
                        onClick={() => delMutation.mutate(r._id)}
                        className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors shrink-0"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default FieldReports;
