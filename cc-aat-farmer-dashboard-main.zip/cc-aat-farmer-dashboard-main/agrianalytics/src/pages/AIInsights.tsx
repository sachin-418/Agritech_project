import { AppSidebar } from "@/components/AppSidebar";
import { DashboardHeader } from "@/components/DashboardHeader";
import { AIRecommendation } from "@/components/AIRecommendation";
import { BrainCircuit, Sparkles, Target, Zap } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { fetchInsights } from "@/lib/api";

const AIInsights = () => {
  const { data: insights = [] } = useQuery({ queryKey: ["insights"], queryFn: fetchInsights });

  return (
    <div className="flex min-h-screen w-full">
      <AppSidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <DashboardHeader />
        <main className="flex-1 p-4 md:p-6 space-y-6 overflow-auto">
          <div>
            <h1 className="text-2xl font-bold text-foreground">AI Insights</h1>
            <p className="text-sm text-muted-foreground mt-1">Machine learning-powered agricultural intelligence</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { label: "Active Models", value: "7", icon: BrainCircuit },
              { label: "Predictions Today", value: "142", icon: Target },
              { label: "Avg Confidence", value: "89%", icon: Sparkles },
            ].map((m) => (
              <div key={m.label} className="glass-card-hover p-5">
                <m.icon className="w-4 h-4 text-primary mb-2" />
                <p className="text-xs text-muted-foreground">{m.label}</p>
                <p className="text-2xl font-bold text-foreground mt-1">{m.value}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-6">
            <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-primary" />
              Latest AI Insights
            </h3>
            <div className="space-y-3">
              {insights.map((insight, i) => (
                <div key={i} className="flex items-center justify-between p-4 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-colors">
                  <div className="flex-1">
                    <p className="text-sm text-foreground">{insight.title}</p>
                    <span className="text-xs text-muted-foreground mt-1">{insight.category}</span>
                  </div>
                  <div className="flex items-center gap-2 ml-4">
                    <div className="w-16 bg-secondary rounded-full h-1.5">
                      <div className="bg-primary rounded-full h-1.5" style={{ width: `${insight.confidence}%` }} />
                    </div>
                    <span className="text-xs font-mono text-primary">{insight.confidence}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <AIRecommendation />
        </main>
      </div>
    </div>
  );
};

export default AIInsights;
