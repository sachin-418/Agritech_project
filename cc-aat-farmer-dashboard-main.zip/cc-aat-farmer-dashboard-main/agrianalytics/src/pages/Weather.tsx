import { AppSidebar } from "@/components/AppSidebar";
import { DashboardHeader } from "@/components/DashboardHeader";
import { CloudRain, Wind, Eye, Sunrise, Sunset, Cloud, Sun, CloudDrizzle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { fetchCurrentWeather, fetchForecast } from "@/lib/api";

const conditionIcon: Record<string, any> = {
  Sunny: Sun,
  Cloudy: Cloud,
  Cloud: Cloud,
  Drizzle: CloudDrizzle,
  Rain: CloudRain,
  "Partly Cloudy": Cloud,
};

const Weather = () => {
  const { data: current } = useQuery({ queryKey: ["weather-current"], queryFn: fetchCurrentWeather });
  const { data: forecast = [] } = useQuery({ queryKey: ["weather-forecast"], queryFn: fetchForecast });

  return (
    <div className="flex min-h-screen w-full">
      <AppSidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <DashboardHeader />
        <main className="flex-1 p-4 md:p-6 space-y-6 overflow-auto">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Weather Forecast</h1>
            <p className="text-sm text-muted-foreground mt-1">7-day weather outlook for your region</p>
          </div>

          <div className="glass-card p-8 glow-effect">
            <div className="flex items-center justify-between flex-wrap gap-6">
              <div>
                <p className="text-sm text-muted-foreground">Current Weather</p>
                <p className="text-6xl font-bold text-foreground mt-2">{current?.temperature ?? "—"}°C</p>
                <p className="text-muted-foreground mt-1">{current?.condition ?? "Loading..."}</p>
              </div>
              <Sun className="w-20 h-20 text-primary opacity-60" />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: "Wind Speed", value: current?.windSpeed ?? "—", icon: Wind },
              { label: "Visibility", value: current?.visibility ?? "—", icon: Eye },
              { label: "Sunrise", value: current?.sunrise ?? "—", icon: Sunrise },
              { label: "Sunset", value: current?.sunset ?? "—", icon: Sunset },
            ].map((m) => (
              <div key={m.label} className="glass-card-hover p-5">
                <m.icon className="w-4 h-4 text-primary mb-2" />
                <p className="text-xs text-muted-foreground">{m.label}</p>
                <p className="text-lg font-bold text-foreground mt-1">{m.value}</p>
              </div>
            ))}
          </div>

          <div className="glass-card p-6">
            <h3 className="text-sm font-semibold text-foreground mb-4">7-Day Forecast</h3>
            <div className="grid grid-cols-7 gap-2">
              {forecast.map((d) => {
                const Icon = conditionIcon[d.condition] || Cloud;
                return (
                  <div key={d.day} className="flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-secondary/50 transition-colors">
                    <span className="text-xs font-medium text-muted-foreground">{d.day}</span>
                    <Icon className="w-6 h-6 text-primary" />
                    <span className="text-sm font-bold text-foreground">{d.high}°</span>
                    <span className="text-xs text-muted-foreground">{d.low}°</span>
                    <div className="flex items-center gap-1">
                      <CloudRain className="w-3 h-3 text-muted-foreground" />
                      <span className="text-[10px] text-muted-foreground">{d.rain}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Weather;
