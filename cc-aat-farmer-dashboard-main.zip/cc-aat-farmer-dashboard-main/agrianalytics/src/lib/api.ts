const API_BASE = "http://localhost:5000/api";

async function fetchJson<T>(url: string): Promise<T> {
  const res = await fetch(`${API_BASE}${url}`);
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

// Climate
export const fetchClimate = () => fetchJson<{
  _id: string;
  temperature: number;
  humidity: number;
  rainfall: number;
  climateRisk: string;
  suitabilityScore: number;
  recommendedCrop: string;
  confidence: number;
  temperatureMatch: number;
  rainfallMatch: number;
  humidityMatch: number;
  soilMatch: number;
}>("/climate");

// Crops
export const fetchCrops = () => fetchJson<{
  _id: string;
  name: string;
  season: string;
  waterReq: string;
  tempRange: string;
  status: string;
  stability: number;
  stdDev: number;
  confidence: number;
}[]>("/crops");

// Monthly climate
export const fetchMonthlyClimate = () => fetchJson<{
  month: string;
  avgTemp: number;
  rainfall: number;
}[]>("/monthly-climate");

// Alerts
export const fetchAlerts = () => fetchJson<{
  _id: string;
  text: string;
  severity: string;
  icon: string;
  active: boolean;
}[]>("/alerts");

// Insights
export const fetchInsights = () => fetchJson<{
  _id: string;
  title: string;
  confidence: number;
  category: string;
}[]>("/insights");

// Heatmap
export const fetchHeatmap = () => fetchJson<{
  temp: number;
  rain: number;
  score: number;
  crop: string;
}[]>("/heatmap");

// Analytics
export const fetchAnalytics = () => fetchJson<{
  _id: string;
  label: string;
  value: string;
  change: string;
  icon: string;
}[]>("/analytics");

// Settings
export const fetchSettings = () => fetchJson<{
  _id: string;
  section: string;
  items: { label: string; value: string }[];
}[]>("/settings");

export const updateSettings = async (id: string, data: { items: { label: string; value: string }[] }) => {
  const res = await fetch(`${API_BASE}/settings/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
};

// Weather
export const fetchCurrentWeather = () => fetchJson<{
  temperature: number;
  condition: string;
  windSpeed: string;
  visibility: string;
  sunrise?: string;
  sunset?: string;
  humidity?: number;
  feelsLike?: number;
}>("/weather/current");

export const fetchForecast = () => fetchJson<{
  day: string;
  condition: string;
  high: number;
  low: number;
  rain: number;
}[]>("/weather/forecast");

// Create a new crop
export const createCrop = async (data: {
  name: string;
  season: string;
  waterReq: string;
  tempRange: string;
  status: string;
}) => {
  const res = await fetch(`${API_BASE}/crops`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || `API error: ${res.status}`);
  }
  return res.json();
};

// Delete a crop
export const deleteCrop = async (id: string) => {
  const res = await fetch(`${API_BASE}/crops/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
};

// Field Reports
export const fetchFieldReports = () => fetchJson<{
  _id: string;
  farmerName: string;
  location: string;
  cropName: string;
  soilMoisture: string;
  cropHealth: string;
  pestIssues: string;
  notes: string;
  createdAt: string;
}[]>("/field-reports");

export const createFieldReport = async (data: {
  farmerName: string;
  location: string;
  cropName: string;
  soilMoisture: string;
  cropHealth: string;
  pestIssues: string;
  notes: string;
}) => {
  const res = await fetch(`${API_BASE}/field-reports`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || `API error: ${res.status}`);
  }
  return res.json();
};

export const deleteFieldReport = async (id: string) => {
  const res = await fetch(`${API_BASE}/field-reports/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
};

// Auth
export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: string;
}

export interface AuthResponse {
  token: string;
  user: AuthUser;
}

export const registerUser = async (data: { name: string; email: string; password: string }): Promise<AuthResponse> => {
  const res = await fetch(`${API_BASE}/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || `API error: ${res.status}`);
  }
  return res.json();
};

export const loginUser = async (data: { email: string; password: string }): Promise<AuthResponse> => {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || `API error: ${res.status}`);
  }
  return res.json();
};

export const fetchCurrentUser = async (): Promise<AuthUser> => {
  const token = localStorage.getItem("token");
  const res = await fetch(`${API_BASE}/auth/me`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
};
